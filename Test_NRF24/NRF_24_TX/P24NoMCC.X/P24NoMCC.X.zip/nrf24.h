
#include <xc.h>
#include <stdint.h>
#include <stdbool.h>
#define _XTAL_FREQ  32000000UL
#define FCY 16000000UL
#include <libpic30.h>
#include "nRF24L01.h"

#define SOFT

#define csnPin1 LATBbits.LATB13 
#define cePin1  LATBbits.LATB14 
#define csnPin2 LATBbits.LATB15 
#define cePin2  LATBbits.LATB9 
#define sckPin  LATBbits.LATB10
#define mosiPin LATBbits.LATB12
#define misoPin LATBbits.LATB11
#ifndef SOFT
void RFSendReceiveOctet(uint8_t* dataout,uint8_t* datain,uint8_t len);
void RFSendMultpileOctet(uint8_t* dataout,uint8_t len);
void RFconfigRegister(uint8_t reg, uint8_t value);
void RFreadRegister(uint8_t reg, uint8_t* value, uint8_t len);
void RFwriteRegister(uint8_t reg, uint8_t* value, uint8_t len) ;
#else
void set_ce(uint8_t state,uint8_t radioNb);
void set_csn(uint8_t state,uint8_t bus);
void set_sck(uint8_t state);
void set_mosi(uint8_t state);
uint8_t get_miso();
uint8_t spi_transfer(uint8_t tx);
void nrf24_transferSync(uint8_t* dataout,uint8_t* datain,uint8_t len);
void nrf24_transmitSync(uint8_t* dataout,uint8_t len);
void nrf24_configRegister(uint8_t reg, uint8_t value,uint8_t bus);
void nrf24_readRegister(uint8_t reg, uint8_t* value, uint8_t len,uint8_t bus);
void nrf24_writeRegister(uint8_t reg, uint8_t* value, uint8_t len,uint8_t bus) ;
void nrf24_powerUpRx(uint8_t radioNb);
void nrf24_config(uint8_t channel, uint8_t pay_length,uint8_t radioNb);
#endif