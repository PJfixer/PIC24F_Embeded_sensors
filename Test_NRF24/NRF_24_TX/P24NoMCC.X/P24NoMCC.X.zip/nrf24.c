
#include "nrf24.h"

#ifndef SOFT
/* envoyer et recvoir plusieurs octet */
void RFSendReceiveOctet(uint8_t* dataout,uint8_t* datain,uint8_t len)
{
    uint8_t i;

    for(i=0;i<len;i++)
    {
        datain[i] = SPI1_Exchange8bit(dataout[i]);
    }

}


// envoyer plusieurs octest
void RFSendMultpileOctet(uint8_t* dataout,uint8_t len)
{
    uint8_t i;
    
    
    for(i=0;i<len;i++)
    {
        SPI1_Exchange8bit(dataout[i]);
    }

}

//ecrire un octet dans un registre
void RFconfigRegister(uint8_t reg, uint8_t value)
{
    csnPin = 0 ;
    SPI1_Exchange8bit(W_REGISTER | (REGISTER_MASK & reg));
    SPI1_Exchange8bit(value);
    csnPin = 1 ;
}

//lire la/les valeurs d'un registres'
void RFreadRegister(uint8_t reg, uint8_t* value, uint8_t len)
{
     csnPin = 0 ;
    SPI1_Exchange8bit(R_REGISTER | (REGISTER_MASK & reg));
    RFSendReceiveOctet(value,value,len);
    csnPin = 1 ;
}

/* Write to a single register of nrf24 */
void RFwriteRegister(uint8_t reg, uint8_t* value, uint8_t len) 
{
    csnPin = 0 ;
    SPI1_Exchange8bit(W_REGISTER | (REGISTER_MASK & reg));
    RFSendMultpileOctet(value,len);
    csnPin = 1 ; 
}
#else

/* software spi routine */

#define HIGH 1
#define LOW 0

void set_ce(uint8_t state,uint8_t radioNb)
{
    switch(radioNb)
    {
        case 1:
            if(state) cePin1=1; else cePin1=0;
        break;
        case 2:
            if(state) cePin2=1; else cePin2=0;
        break;
      
    }
}
/* ------------------------------------------------------------------------- */
void set_csn(uint8_t state,uint8_t bus)
{
    switch(bus)
    {
        case 1:
            if(state) csnPin1=1; else csnPin1=0;
        break;
        case 2:
            if(state) csnPin2=1; else csnPin2=0;
        break;
       
        
    }
    
}
/* ------------------------------------------------------------------------- */
void set_sck(uint8_t state)
{
    if(state) LATBbits.LATB10=1; else LATBbits.LATB10=0;
}
/* ------------------------------------------------------------------------- */
void set_mosi(uint8_t state)
{
    if(state) LATBbits.LATB12=1; else LATBbits.LATB12=0;
}
/* ------------------------------------------------------------------------- */
uint8_t get_miso()
{
    return PORTBbits.RB11;
}

uint8_t spi_transfer(uint8_t tx)
{
    uint8_t i = 0;
    uint8_t rx = 0;    

    set_sck(0);

    for(i=0;i<8;i++)
    {

        if(tx & (1<<(7-i)))
        {
            set_mosi(1);            
        }
        else
        {
            set_mosi(0);
        }

        set_sck(1);        

        rx = rx << 1;
        if(get_miso())
        {
            rx |= 0x01;
        }

        set_sck(0);                

    }

    return rx;
}

/* send and receive multiple bytes over SPI */
void nrf24_transferSync(uint8_t* dataout,uint8_t* datain,uint8_t len)
{
    uint8_t i;

    for(i=0;i<len;i++)
    {
        datain[i] = spi_transfer(dataout[i]);
    }

}

/* send multiple bytes over SPI */
void nrf24_transmitSync(uint8_t* dataout,uint8_t len)
{
    uint8_t i;
    
    for(i=0;i<len;i++)
    {
        spi_transfer(dataout[i]);
    }

}

/* Clocks only one byte into the given nrf24 register */
void nrf24_configRegister(uint8_t reg, uint8_t value,uint8_t bus)
{
    set_csn(0,bus);
    spi_transfer(W_REGISTER | (REGISTER_MASK & reg));
    spi_transfer(value);
    set_csn(1,bus);
}

/* Read single register from nrf24 */
void nrf24_readRegister(uint8_t reg, uint8_t* value, uint8_t len,uint8_t bus)
{
    set_csn(0,bus);
    spi_transfer(R_REGISTER | (REGISTER_MASK & reg));
    nrf24_transferSync(value,value,len);
    set_csn(1,bus);
}

/* Write to a single register of nrf24 */
void nrf24_writeRegister(uint8_t reg, uint8_t* value, uint8_t len,uint8_t bus) 
{
    set_csn(0,bus);
    spi_transfer(W_REGISTER | (REGISTER_MASK & reg));
    nrf24_transmitSync(value,len);
    set_csn(1,bus);
}

void nrf24_config(uint8_t channel, uint8_t pay_length,uint8_t radioNb)
{
  

    // Set RF channel
    nrf24_configRegister(RF_CH,channel,radioNb);

    // Set length of incoming payload 
    nrf24_configRegister(RX_PW_P0, 0x00,radioNb); // Auto-ACK pipe ...
    nrf24_configRegister(RX_PW_P1, pay_length,radioNb); // Data payload pipe
    nrf24_configRegister(RX_PW_P2, 0x00,radioNb); // Pipe not used 
    nrf24_configRegister(RX_PW_P3, 0x00,radioNb); // Pipe not used 
    nrf24_configRegister(RX_PW_P4, 0x00,radioNb); // Pipe not used 
    nrf24_configRegister(RX_PW_P5, 0x00,radioNb); // Pipe not used 

    // 1 Mbps, TX gain: 0dbm
    //nrf24_configRegister(RF_SETUP, (0<<RF_DR)|((0x03)<<RF_PWR));
	// 250Kbps, TXgain 0dbm 
	nrf24_configRegister(RF_SETUP,0b00100110,radioNb);
	

    // CRC enable, 1 byte CRC length
    nrf24_configRegister(CONFIG,((1<<EN_CRC)|(0<<CRCO)),radioNb);

    // Auto Acknowledgment
    nrf24_configRegister(EN_AA,(1<<ENAA_P0)|(1<<ENAA_P1)|(0<<ENAA_P2)|(0<<ENAA_P3)|(0<<ENAA_P4)|(0<<ENAA_P5),radioNb);

    // Enable RX addresses
    nrf24_configRegister(EN_RXADDR,(1<<ERX_P0)|(1<<ERX_P1)|(0<<ERX_P2)|(0<<ERX_P3)|(0<<ERX_P4)|(0<<ERX_P5),radioNb);

    // Auto retransmit delay: 1000 us and Up to 15 retransmit trials
    nrf24_configRegister(SETUP_RETR,(0xFF<<ARD)|(0x0F<<ARC),radioNb);

    // Dynamic length configurations: No dynamic length
    nrf24_configRegister(DYNPD,(0<<DPL_P0)|(0<<DPL_P1)|(0<<DPL_P2)|(0<<DPL_P3)|(0<<DPL_P4)|(0<<DPL_P5),radioNb);

    // Start listening
    nrf24_powerUpRx(radioNb);
}

void nrf24_powerUpRx(uint8_t radioNb)
{     
    set_csn(0,radioNb);
    spi_transfer(FLUSH_RX);
    set_csn(1,radioNb);

    nrf24_configRegister(STATUS,(1<<RX_DR)|(1<<TX_DS)|(1<<MAX_RT),radioNb); 

    set_ce(0,radioNb);    
    nrf24_configRegister(CONFIG,((1<<EN_CRC)|(0<<CRCO))|((1<<PWR_UP)|(1<<PRIM_RX)),radioNb);    
    set_ce(1,radioNb);
}

#endif